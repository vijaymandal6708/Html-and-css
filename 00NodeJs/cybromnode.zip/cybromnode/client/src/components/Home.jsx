import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to Home Page</h1>
      <hr />
    </div>
  );
};

export default Home;
